This directory contains
1) The project proposal - 'des_proposal_Anchit_Anand.pdf'
2) The presentation - 'Presentation_Part1.pdf'
3) The code, in files appropriately named. 
	To execute the code, run 'make' followed by './a.out > tr.txt'
	This generates the trace in the file 'tr.txt'. 
	The trace has the follwing general format :- 'timestamp eventType description', 
		with the description varying with the type of the event. 